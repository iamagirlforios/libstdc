# Xcode_libstdc

```Xcode10```和```Xcode11``` 中路径不同，请仔细查看。

1. 先现在对应文件，终端cd到Xcode_libstdc文件夹；
2. 如果你使用的是Xcode10，请ssh执行```install-Xcode_10.sh```。如使用Xcode11则执行将```install-Xcode_11.sh```







